package be.ugent.lwdbie.ajaxrestspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjaxRestSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjaxRestSpringApplication.class, args);
	}

}
