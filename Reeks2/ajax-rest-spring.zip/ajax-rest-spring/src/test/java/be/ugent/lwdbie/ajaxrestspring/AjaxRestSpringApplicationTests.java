package be.ugent.lwdbie.ajaxrestspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjaxRestSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
