const express = require('express');
const path = require('path');
const WebSocket = require('ws');
const app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

let generate_random_data = () => {
  return Array(30).fill().map((e, i) => {
    return {"date": new Date(2019, 10, i), "temp": 15 + (Math.random() * 10)}
  });
};
let temperatures = {};
let connections = {};
for (let room of ["bedroom", "office", "kitchen", "bathroom"]) {
  temperatures[room] = generate_random_data();
  connections[room] = [];
}


app.get("/", (req, res) => {
  res.render("index");
});

app.get("/temperatures", (req, res) => {
  console.log("/temperatures");
  res.json(temperatures);
});

app.get("/rooms", (req, res) => {
  res.json(Object.keys(temperatures));
});

app.get("/temperatures/:room", (req, res) => {
  res.json(temperatures[req.params.room])
});

app.post("/temperatures/:room", (req, res) => {
  console.log(req.body);
  let d = {
    "date": new Date(),
    "temp": req.body.temperature
  };
  temperatures[req.params.room].push(d);
  console.log(temperatures[req.params.room]);
  res.status(202);
  res.end();
  for (let c of connections[req.params.room]) {
    c.send(JSON.stringify([d]));
  }
});

const wss = new WebSocket.Server({port: 8080});

wss.on('connection', function connection(ws, req) {
  let room = req.url.split("=")[1];
  ws.send(JSON.stringify(temperatures[room]));
  connections[room].push(ws);
});


module.exports = app;
