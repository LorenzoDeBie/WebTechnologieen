let generate_random_data = () => {
    return Array(30).fill().map((e,i)=>{return {"date": new Date(2018, 10, i), "temp": 15 + (Math.random() * 10)}});
};
let temperatures = {};
for (let room of ["bedroom", "office", "kitchen", "bathroom"]){
    temperatures[room] = generate_random_data();
}
