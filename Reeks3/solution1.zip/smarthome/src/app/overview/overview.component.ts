import { Component, OnInit } from '@angular/core';
import {FetchService} from '../fetch.service';
import {RestResponse} from '../RestResponse';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {
  n = 5;
  notifications = [];

  constructor(private service: FetchService) {
    service.landen.subscribe((d: RestResponse)=> this.notifications = d.notifications);
  }

  ngOnInit() {
  }

  more() {
    console.log('more');
    this.n += 5;
  }

}
