export interface RestResponse{
  notifications: Notification[];
}
