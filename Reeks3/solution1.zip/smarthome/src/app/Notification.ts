export interface Notification{
  id: number;
  message: string;
  icon: string;
}
