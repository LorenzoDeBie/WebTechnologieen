import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {map, tap} from 'rxjs/operators';
import {RestResponse} from './RestResponse';

@Injectable()
export class FetchService {
  url = 'http://www.mocky.io/v2/5be453402f00002c00d9f48f';

  constructor(private http: HttpClient) { }

  get landen(): Observable<RestResponse> {
    return this.http.get<RestResponse>(this.url);
  }


}
